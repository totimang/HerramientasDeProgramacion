#include<stdio.h>
#include<stdlib.h>
#include<iostream>
using namespace std;

main()
{
	printf ("Integrantes:\nJuan_Cruz Baravalle\nBernardo_Emilio Pincione\nRodrigo_Damian Martinez\n");
	getchar();
	char car='s';
	int a=0, b=0, c=0;

	while (car=='s')
		{

		printf("Ingrese un valor: ");
		scanf("%d", &a);
		printf("Ingrese un valor: ");
		scanf("%d", &b);	
	if(a % 2 == 0){
		c=a+b;
		printf("El total de los valores %d + %d es: %d \n\n" a,b,c);
	}
	else{
		printf("El n�mero ingresado no es par, vuelva ingresar un n�mero")
	}

	printf("�Desea volver a cargar n�meros? Ingrese si(s) o no(n): ");
	cin>>car;

	while(car !='s' && car !='n')
	{
		printf("\n La respuesta ingresada es incorrecta. Por favor ingrese s/n (si o no))");
		cin>>car;
		
			}		
}	
system ("PAUSE");
return 0;

}
